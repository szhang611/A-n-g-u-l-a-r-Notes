/**
 * logout action creator
 */
export const logout = () => {
    return {
        type: 'logout'
    };
};

