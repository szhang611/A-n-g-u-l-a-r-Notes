/**
 * end loading action creator
 */
export const endLoading = () => {
    return {
        type: 'endLoading',
        payload: true
    };
};