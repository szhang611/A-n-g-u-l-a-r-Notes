import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
  Text,
  StyleSheet,
  StatusBar,
  Dimensions,
  BackHandler,
  Animated,
  Image,
  Alert,
    View,
    TouchableOpacity,
    AsyncStorage,
} from 'react-native'
import VideoPlayer from 'react-native-video'
import KeepAwake from 'react-native-keep-awake'
import Orientation from 'react-native-orientation'
import Icons from 'react-native-vector-icons/MaterialIcons'
import Controls from './Controls'
import { checkSource } from './utils'
import Spinner from 'react-native-spinkit'
import AllUrls from '../../../services/APIUrl';


const Win = Dimensions.get('window')
const backgroundColor = 'transparent'

const styles = StyleSheet.create({
  background: {
    backgroundColor,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1
  },
  fullScreen: {
    ...StyleSheet.absoluteFillObject
  },
  image: {
    ...StyleSheet.absoluteFillObject,
    width: undefined,
    height: undefined,
    zIndex: 2
  },
    controlBottom: {
      width: '100%',
        height: 3,
        backgroundColor: 'black',
        position: 'relative',
        bottom: 0,
        left: 0
    }
})

const defaultTheme = {
  title: '#FFF',
  more: '#FFF',
  center: '#FFF',
  fullscreen: '#FFF',
  volume: '#FFF',
  scrubberThumb: '#FFF',
  scrubberBar: '#FFF',
  seconds: '#FFF',
  duration: '#FFF',
  progress: '#FFF',
  loading: '#FFF'
}

class Video extends Component {
  constructor(props) {
    super(props)
    this.state = {
      paused: !props.autoPlay,
      muted: false,
      fullScreen: false,
      inlineHeight: Win.width * 0.3,
      loading: false,
      duration: 0,
      progress: 0,
      buffered: 0,
      currentTime: 0,
      seeking: false,
      renderError: false,
      maxTime: 1,
      pan: new Animated.ValueXY(),
      uid: '',
      showCoverFullScreenButton: true,
    };
    this.animInline = new Animated.Value(Win.width * 0.3)
    this.animFullscreen = new Animated.Value(Win.width * 0.3)
    this.BackHandler = this.BackHandler.bind(this)
    this.onRotated = this.onRotated.bind(this)
  }

  componentWillMount() {
      if(this.props.hideCoverFullScreenIcon) {
          this.setState({showCoverFullScreenButton: false});
      }
  }

  componentDidMount() {
    Dimensions.addEventListener('change', this.onRotated)
    BackHandler.addEventListener('hardwareBackPress', this.BackHandler)
      AsyncStorage.getItem('USER_ID').then((uid) => {
        this.setState({uid: uid});
        if(this.props.socket) {
              this.emitSocketInterval(uid);
          }
      });
  }

  componentWillUnmount() {
    clearInterval(this.watchingSocketInterval);
    if(this.props.socket) {
        this.props.socket.emit('watchingNow', this.state.uid, {});
    }

    Dimensions.removeEventListener('change', this.onRotated)
    BackHandler.removeEventListener('hardwareBackPress', this.BackHandler)
  }
  
  emitSocketInterval(uid){
      this.watchingSocketInterval = setInterval(()=>{
          if(this.props.hamburgerActions && this.props.hamburgerActions.Recorded_CurrentVideoName && this.props.socket) {
              this.props.socket.emit('watchingNow', uid,
                  {
                      contentid:this.props.hamburgerActions.Recorded_CurrentVideoName,
                      video: {
                          type: 'OTT',
                          offset: this.state.currentTime.toFixed(0),
                          url: AllUrls.videoUri(this.props.hamburgerActions.Recorded_CurrentVideoName)
                      }
                  }
              );
          }
      }, 3000)
  }

  onLoadStart() {
    this.setState({ paused: true, loading: true })
  }

  onLoad(data) {
    this.setState({loading: false, paused: false})
    if (!this.state.loading) return
    this.props.onLoad(data)
    const { height, width } = data.naturalSize   
    const ratio = height === 'undefined' && width === 'undefined' ?
      (9 / 16) : (height / width)
    // const inlineHeight = this.props.lockRatio ?
    //   (Win.width / this.props.lockRatio)
    //   : (Win.width * ratio)
    const inlineHeight = Win.width * 0.3;
    this.setState({
      paused: !this.props.autoPlay,
      loading: false,
      inlineHeight,
      duration: data.duration
    }, () => {
      Animated.timing(this.animInline, { toValue: inlineHeight, duration: 200 }).start()
      this.props.onPlay(!this.state.paused)
      if (!this.state.paused) {
        KeepAwake.activate()
        if (this.props.fullScreenOnly) {
          // this.setState({ fullScreen: true }, () => {
          //   this.props.onFullScreen(this.state.fullScreen)
          //   this.animToFullscreen(Win.height)
          //   if (this.props.rotateToFullScreen) Orientation.lockToLandscape()
          // })
        }
      }
    })
  }

  onBuffer() {
    // console.log('buffering')
      if(this.state.paused) {
          this.setState({ loading: true })
      } else {
          this.setState({ loading: false })
      }
  }

  onEnd() {
    this.props.onEnd()
    const { loop } = this.props
    if (!loop) this.pause()
    this.onSeekRelease(0)
    this.setState({ currentTime: 0 }, () => {
      // if (!loop) this.controls.showControls()
    })
      this.setState({loading: false});
  }

  onRotated({ window: { width, height } }) {
    // debugger
    // Add this condition incase if inline and fullscreen options are turned on
    // if (this.props.inlineOnly) return
    // const orientation = width > height ? 'LANDSCAPE' : 'PORTRAIT'
    // if (this.props.rotateToFullScreen) { // rotateToFullScreen is always false
    //   if (orientation === 'LANDSCAPE') {
    //     this.setState({ fullScreen: true }, () => {
    //       this.animToFullscreen(height)
    //       this.props.onFullScreen(this.state.fullScreen)
    //     })
    //     return
    //   }
    //   if (orientation === 'PORTRAIT') {
    //     this.setState({
    //       fullScreen: false,
    //       paused: this.props.fullScreenOnly || this.state.paused
    //     }, () => {
    //       this.animToInline()
    //       if (this.props.fullScreenOnly) this.props.onPlay(!this.state.paused)
    //       this.props.onFullScreen(this.state.fullScreen)
    //     })
    //     return
    //   }
    // } else {
    //   this.animToInline() //will run this
    // }
    // if (this.state.fullScreen) this.animToFullscreen(height) //will run this
  }

  onSeekRelease(percent) {
    const seconds = percent * this.state.duration
    // const seconds = percent * this.state.maxTime
    this.setState({ progress: percent, seeking: false, currentTime: Math.floor(seconds)}, () => {
      this.player.seek(Math.floor(seconds), 500);
    })
  }

  onError(msg) {
    this.props.onError(msg)
    const { error } = this.props
    this.setState({ renderError: true }, () => {
      let type
      switch (true) {
        case error === false:
          type = error
          break
        case typeof error === 'object':
          type = Alert.alert(error.title, error.message, error.button, error.options)
          break
        default:
          type = Alert.alert('Oops!', 'There was an error playing this video, please try again later.', [{ text: 'Close' }])
          break
      }
      return type
    })
  }

  BackHandler() {
    if (this.state.fullScreen) {
      // debugger
      this.setState({ fullScreen: false }, () => {
        this.animToInline()
        this.props.onFullScreen(this.state.fullScreen)
        if (this.props.fullScreenOnly && !this.state.paused) this.togglePlay()
        if (this.props.rotateToFullScreen) Orientation.lockToPortrait()
        setTimeout(() => {
          if (!this.props.lockPortraitOnFsExit) Orientation.unlockAllOrientations()
        }, 1500)
      })
      return true
    }
    return false
  }

  pause() {
    if (!this.state.paused) this.togglePlay()
  }

  play() {
    if (this.state.paused) this.togglePlay()
  }

  togglePlay() {
    this.setState({ paused: !this.state.paused }, () => {
      this.props.onPlay(!this.state.paused)
      Orientation.getOrientation((e, orientation) => {
        if (this.props.inlineOnly) return
        if (!this.state.paused) {
          if (this.props.fullScreenOnly && !this.state.fullScreen) {
            this.setState({ fullScreen: true }, () => {
              this.props.onFullScreen(this.state.fullScreen)
              const initialOrient = Orientation.getInitialOrientation()
              const height = orientation !== initialOrient ?
                Win.width : Win.height
              this.animToFullscreen(height)
              if (this.props.rotateToFullScreen) Orientation.lockToLandscape()
            })
          }
          KeepAwake.activate()
        } else {
          KeepAwake.deactivate()
        }
      })
    })
  }

  pauseIt() {
      this.setState({ paused: true }, () => {
          this.props.onPlay(false)
          Orientation.getOrientation((e, orientation) => {
              if (this.props.inlineOnly) return
              if (false) {
                  KeepAwake.activate()
              } else {
                  KeepAwake.deactivate()
              }
          })
      })
  }

  toggleFS() {
    this.setState({ fullScreen: !this.state.fullScreen }, () => {
      // debugger
      Orientation.getOrientation((e, orientation) => {
        if (this.state.fullScreen) {
          const initialOrient = Orientation.getInitialOrientation()
          const height = orientation !== initialOrient ?
            Win.width : Win.height
            this.props.onFullScreen(this.state.fullScreen)
            if (this.props.rotateToFullScreen) Orientation.lockToLandscape()
            this.animToFullscreen(height)
        } else {
          if (this.props.fullScreenOnly) {
            this.setState({ paused: true }, () => this.props.onPlay(!this.state.paused))
          }
          this.props.onFullScreen(this.state.fullScreen)
          if (this.props.rotateToFullScreen) Orientation.lockToPortrait()
          this.animToInline()
          setTimeout(() => {
            if (!this.props.lockPortraitOnFsExit) Orientation.unlockAllOrientations()
          }, 1500)
        }
      })
    })
  }

  animToFullscreen(height) {
    // debugger
    // Animated.parallel([
    //   Animated.timing(this.animFullscreen, { toValue: Win.width * 0.6, duration: 200 }),
    //   Animated.timing(this.animInline, { toValue: Win.width * 0.6, duration: 200 })
    // ]).start()
  }

  animToInline(height) {
    // debugger
    const newHeight = this.state.inlineHeight
    // const newHeight = height || this.state.inlineHeight
    // Animated.parallel([
    //   Animated.timing(this.animFullscreen, { toValue: newHeight, duration: 100 }),
    //   Animated.timing(this.animInline, { toValue: this.state.inlineHeight, duration: 100 })
    // ]).start()
  }

  toggleMute() {
    this.setState({ muted: !this.state.muted })
  }

  seek(percent) {
    const currentTime = percent * this.state.duration
    this.setState({ seeking: true, currentTime:currentTime })
  }

  seekTo(seconds) {
    const percent = seconds / this.state.duration
    if (seconds > this.state.duration) {
      throw new Error(`Current time (${seconds}) exceeded the duration ${this.state.duration}`)
      return false
    }
    return this.onSeekRelease(percent)
  }

  progress(time) {
    if(this.state.loading) {
      this.setState({loading: false});
    }
    const { currentTime, playableDuration } = time
     
      const progress = currentTime / this.state.duration
      const buffered = playableDuration / this.state.duration
      // if(currentTime > this.state.maxTime) {
      //   this.setState({maxTime: currentTime})
      // }
    // const progress = currentTime / this.state.maxTime
    if (!this.state.seeking) {
      this.setState({ progress, currentTime, buffered }, () => {
        this.props.onProgress(time)
      })
    }
  }

  getMaxTime = (val) => {
    this.setState({maxTime: val});
}

    onVideoNativeSeek () {
        // if(this.state.paused) {
        //     this.setState({ loading: true })
        // } else {
        //     this.setState({ loading: false })
        // }
    }

  renderError() {
    const { fullScreen } = this.state
    const inline = {
      height: this.animInline,
      alignSelf: 'stretch',
        flex: 1,
    }
    const textStyle = { color: 'white', padding: 10 }
    return (
      <Animated.View
        style={[styles.background, fullScreen ? styles.fullScreen : inline]}
      >
        <Text style={textStyle}>Retry</Text>
        <Icons
          name="replay"
          size={60}
          color={'#FFF'}
          onPress={() => this.setState({ renderError: false })}
        />
      </Animated.View>
    )
  }

  renderPlayer() {
    const {
      fullScreen,
      paused,
      muted,
      loading,
      progress,
      buffered,
      duration,
      inlineHeight,
      currentTime
    } = this.state

    const {
      url,
      loop,
      title,
      logo,
      rate,
      style,
      volume,
      bufferConfig,
      placeholder,
      poster,
      theme,
      onTimedMetadata,
      resizeMode,
      onMorePress,
      inlineOnly,
      playInBackground,
      playWhenInactive,
        showLive,
        isLiveFullScreen,
        displayFullScreenIcon,
        displayEditIcon,
    } = this.props

    const inline = {
      height: '120%',
      alignSelf: 'stretch',
        backgroundColor: 'transparent'  ,
        // flex: 1,
    }

    const setTheme = {
      ...defaultTheme,
      ...theme
    }
    // debugger

      console.log('-----------------------Render OTT video-----------------------');
    return (
      <Animated.View
        style={[
          styles.background,
          // fullScreen ?
          //   (styles.fullScreen, { height: Win.width * 0.6 })
          //   : { height: Win.width * 0.6 },
          fullScreen ? null : style
        ]}
      >
        {/*<StatusBar hidden={isLiveFullScreen} />*/}
        { 
          ((poster) && currentTime < 0.01) &&
          <Image resizeMode="cover" style={styles.image} {...checkSource(poster)} />
        }
        <VideoPlayer
          {...checkSource(url)}
          bufferConfig={bufferConfig}
          paused={paused}
          resizeMode={resizeMode}
          repeat={loop}
          style={fullScreen ? styles.fullScreen : inline}
          ref={(ref) => { this.player = ref }}
          rate={rate}
          volume={volume}
          muted={muted}
          playInBackground={playInBackground} // Audio continues to play when app entering background.
          playWhenInactive={playWhenInactive} // [iOS] Video continues to play when control or notification center are shown.
          // progressUpdateInterval={250.0}          // [iOS] Interval to fire onProgress (default to ~250ms)
          onLoadStart={() => this.onLoadStart()} // Callback when video starts to load
          onLoad={e => this.onLoad(e)} // Callback when video loads
          onProgress={e => this.progress(e)} // Callback every ~250ms with currentTime
          onEnd={() => this.onEnd()}
          onError={e => this.onError(e)}
          // onBuffer={() => this.onBuffer()} // Callback when remote video is buffering
          onTimedMetadata={e => onTimedMetadata(e)} // Callback when the stream receive some metadata
            onSeek={e => this.onVideoNativeSeek(e)}
        />
          {
            !this.state.loading &&
            <Controls
                ref={(ref) => { this.controls = ref }}
                toggleMute={() => this.toggleMute()}
                toggleFS={() => this.props.toggleFullScreen()}
                // toggleFS={() => this.toggleFS()}
                togglePlay={() => this.togglePlay()}
                paused={paused}
                muted={muted}
                fullscreen={fullScreen}
                loading={loading}
                onSeek={val => this.seek(val)}
                onSeekRelease={pos => this.onSeekRelease(pos)}
                progress={progress}
                buffered = {buffered}
                currentTime={currentTime}
                duration={duration}
                logo={logo}
                title={title}
                more={!!onMorePress}
                onMorePress={() => onMorePress()}
                theme={setTheme}
                inlineOnly={inlineOnly}
                showLive={showLive}
                isLiveFullScreen={isLiveFullScreen}
                callback={this.getMaxTime.bind(this)}
                displayFullScreenIcon={displayFullScreenIcon}
                displayEditIcon={displayEditIcon}
                pressEditIcon={()=>this.props.pressEditIcon()}
            />
          }

          {
              this.state.loading &&
              <View style={{flex: 1, justifyContent:'center', alignItems:'center', ...StyleSheet.absoluteFillObject, zIndex: 99}}>
                <Spinner type={'Circle'} color={'#f1f1f1'} size={60}/>
              </View>
          }
          {
              this.state.loading && this.state.showCoverFullScreenButton &&
                <TouchableOpacity style={{position: 'absolute', bottom: 5, right: 5, zIndex: 100}} onPress={() => this.props.toggleFullScreen()}>
                  <Icons name={isLiveFullScreen ? 'fullscreen-exit' : 'fullscreen'} color={'#FFFFFF'} size={30}/>
                </TouchableOpacity>
          }

      </Animated.View>
    )
  }

  render() {
    if (this.state.renderError) return this.renderError()
    return this.renderPlayer()
  }
}

Video.propTypes = {
  url: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]).isRequired,
  placeholder: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  style: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.number
  ]),
  error: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.object
  ]),
  loop: PropTypes.bool,
  autoPlay: PropTypes.bool,
  inlineOnly: PropTypes.bool,
  fullScreenOnly: PropTypes.bool,
  playInBackground: PropTypes.bool,
  playWhenInactive: PropTypes.bool,
  rotateToFullScreen: PropTypes.bool,
  lockPortraitOnFsExit: PropTypes.bool,
  onEnd: PropTypes.func,
  onLoad: PropTypes.func,
  onPlay: PropTypes.func,
  onError: PropTypes.func,
  onProgress: PropTypes.func,
  onMorePress: PropTypes.func,
  onFullScreen: PropTypes.func,
  onTimedMetadata: PropTypes.func,
  onVideoNativeSeek: PropTypes.func,
  togglePlay: PropTypes.func,
  pauseIt: PropTypes.func,
  rate: PropTypes.number,
  volume: PropTypes.number,
  poster: PropTypes.string,
  bufferConfig: PropTypes.object,
  lockRatio: PropTypes.number,
  logo: PropTypes.string,
  title: PropTypes.string,
  theme: PropTypes.object,
  resizeMode: PropTypes.string,
    showLive: PropTypes.bool,
    isLiveFullScreen: PropTypes.bool,
    toggleFullScreen: PropTypes.func,
    displayFullScreenIcon: PropTypes.bool,
    displayEditIcon: PropTypes.bool,
    pressEditIcon: PropTypes.func,
}

Video.defaultProps = {
  placeholder: undefined,
  style: {},
  error: true,
  loop: false,
  autoPlay: false,
  inlineOnly: false,
  fullScreenOnly: false,
  playInBackground: false,
  playWhenInactive: false,
  rotateToFullScreen: false,
  lockPortraitOnFsExit: false,
  onEnd: () => {},
  onLoad: () => {},
  onPlay: () => {},
  onError: () => {},
  onProgress: () => {},
  onMorePress: undefined,
  onFullScreen: () => {},
  onTimedMetadata: () => {},
  onVideoNativeSeek: () => {},
  pressEditIcon: () => {},
  togglePlay: this.togglePlay,
  pauseIt: this.pauseIt,
  rate: 1,
  volume: 1,
  lockRatio: undefined,
  logo: undefined,
  poster: undefined,
  bufferConfig : {
    minBufferMs: 15000,
    maxBufferMs: 50000,
    bufferForPlaybackMs: 2500,
    bufferForPlaybackAfterRebufferMs: 5000
  } ,
  title: '',
  theme: defaultTheme,
  resizeMode: 'contain',
    showLive: false,
    isLiveFullScreen: false,
    displayFullScreenIcon: true,
    displayEditIcon: false,
};

export default Video
