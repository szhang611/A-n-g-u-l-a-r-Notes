import React from 'react';
import { View, Text, StyleSheet } from 'react-native';


export default TableItem = function (props) {
    return (
        <View style={props.style}>
            <Button onPress={} title={props.title} />
        </View>
    )
}