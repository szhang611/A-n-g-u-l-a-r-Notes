<template>
  <div>
    <layout>

    </layout>
  </div>
</template>

<script>
  import layout from '../../components/common/layout.vue'
  export default {
    components: {
      layout
    }
  }
</script>

<style>

</style>
